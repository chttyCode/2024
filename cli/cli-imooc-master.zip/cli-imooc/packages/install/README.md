# `install`

> TODO: description

## Usage

```
const install = require('install');

// TODO: DEMONSTRATE API
```
