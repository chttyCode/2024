# `command`

> TODO: description

## Usage

```
const command = require('command');

// TODO: DEMONSTRATE API
```
