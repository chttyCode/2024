# `cli`

> TODO: description

## Usage

```
const cli = require('cli');

// TODO: DEMONSTRATE API
```
