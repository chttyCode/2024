# `lint`

> TODO: description

## Usage

```
const lint = require('lint');

// TODO: DEMONSTRATE API
```
