# GitFlow原理

## GitFlow主流程
> 原稿：[https://nvie.com/posts/a-successful-git-branching-model/](https://nvie.com/posts/a-successful-git-branching-model/)

![img](./w28-c2-main.jpg)

## GitFlow多人协作流程
![img](./w28-c2-multi.jpg)
