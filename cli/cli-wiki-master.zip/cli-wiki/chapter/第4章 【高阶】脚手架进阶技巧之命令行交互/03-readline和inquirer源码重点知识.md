# readline 和 inquirer 源码重点知识

## readline

### 知识点1：


## inquirer

### 知识点2：

