'use strict';

exports.mongoose = {
  enable: true,
  package: 'egg-mongoose',
};
